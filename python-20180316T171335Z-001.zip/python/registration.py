#import factory
import signup
def fun_reg():
    print("*** REGISTRATION ***\n")
    signup.newuser()
    print("*** Thank you ***\n")
