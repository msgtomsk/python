import pickle
#print("factory")
detailsnew = {}
password = {}
nameli=[]

'''print(detailsnew)

nameli.append("a")
fpn = open("name.txt","wb+")
pickle.dump(nameli,fpn)

password["a"] = "a"
li = []
reg = []

fpp = open("pwdf.txt","wb+")
pickle.dump(password,fpp)
fpd = open("details.txt","wb+")
pickle.dump("details",fpd)
pickle.dump(detailsnew,fpd)
fpr = open("regis.txt","wb+")
pickle.dump(detailsnew,fpr)'''

fpn = open("name.txt","w+")
