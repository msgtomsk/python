import signup
def fun_user():
    while True:
        try:
            print("\n*** USER LOGIN ***\n")
            print("1.Registration\n2.profile\n3.Logout")
            choice2 = int(input("Enter :"))
            if choice2 == 1:
                Registration.fun_reg()
            elif choice2 == 2:                
                fpn = open("name.txt","wb+")
                fpd = open("details.txt","rb+")
                val = pickle.load(fpd)
                print()
                for k in val:
                    print("{} : {}".format(k,detailsnew[k]))
            elif choice2 == 3:
                break
        except Exception:
            print("\nInvalid input\n")