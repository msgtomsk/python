import pickle
def authenticate(uname,pwd):
    fpn = open("name.txt","rb+")
    name = pickle.load(fpn)
    fpp = open("pwdf.txt","rb+")
    fpwd = pickle.load(fpp)
    for i in name:
        if uname == i:
            if pwd == fpwd[uname]:                
                return True
            else:
                return False
