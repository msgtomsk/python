import random,registration,user
#import factory
import pickle
def newuser():
    print("\n*** SIGNUP ***\n")
    ''' name = input("Enter the Name : ")
    factory.detailsnew["Name"] = name
    factory.nameli.append(name)
    factory.password[name] = input("Enter the password : ")
    factory.detailsnew["empid"] = random.randint(100,999)
    factory.detailsnew["Address"] = input("Enter the address : ")
    factory.detailsnew["Dob"] = input("Enter the Date Of Birth : ")
    factory.detailsnew["Accounttype"] = input("Enter the Account Type : ")
    factory.detailsnew["Addproof"] = input("Enter the Address Proof Number : ")
    #detailsnew["Accountnumber"] = input("Enter the Account number : ")    
    #factory.li.append(detailsnew)
    fpd = open("details.txt","rb+")
    details = pickle.load(fpd)
    print(details)
    print("Name : ",name)
    print("Employee id :")
    print(factory.detailsnew)'''
    detailsnew = {}
    nameli = []
    password = {}
    name = input("Enter the Name : ")
    detailsnew["Name"] = name
    if name in nameli:
        print("User name already exist !!!!\n")
    else:    
        nameli.append(name)
        password[name] = input("Enter the password : ")
        detailsnew["empid"] = "EID" + str(random.randint(100,999))
        detailsnew["Address"] = input("Enter the address : ")
        detailsnew["Dob"] = input("Enter the Date Of Birth : ")
        detailsnew["Accounttype"] = input("Enter the Account Type : ")
        detailsnew["Addproof"] = input("Enter the Address Proof Number : ")
        fpd = open("details.txt","wb+")
        pickle.dump(detailsnew,fpd)
        fpn = open("name.txt","wb+")
        pickle.dump(nameli,fpn)
        fpp = open("pwdf.txt","wb+")
        pickle.dump(password,fpp)
        fpd = open("details.txt","rb+")
        val = pickle.load(fpd)
        print()
        for k in val:
            print("{} : {}".format(k,detailsnew[k]))
        print(" *** ***\n")        
        user.fun_user()