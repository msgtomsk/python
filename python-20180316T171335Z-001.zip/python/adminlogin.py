def fun_admin():
    global status
    status = "false"
    print("Username : admin")
    pwd1 = input("Enter the password : ")
    if pwd1 == "admin":
        global status
        print("*** admin login successful ***\n")
        status = "true"
        #fp = open("emp.txt","w+")
    else:
        print("\nInvalid password\n")
