import authen,user
def Login():
    print("*** SIGNIN ***")
    uname = input("Enter the User Name : ")
    pwd = input("Enter the Password : ")
    if authen.authenticate(uname,pwd):
        print()
        user.fun_user()
    else:
        print("\n*** Invalid Username or Password ***\n")        
