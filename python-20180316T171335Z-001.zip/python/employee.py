import registration,view,generate
def fun_emp():
    while 1:
        print("1.Registration\n2.View\n3.Generate payslip\n4.Generate reports\n5.Exit")
        choice2 = int(input())
        if choice2 == 1:
            registration.fun_reg()
        elif choice2 == 2:
            view.fun_view()
        elif choice2 == 3:
            generate.fun_pay()
        elif choice2 == 4:
            generate.fun_rep()
        elif choice2 == 5:
            break        
        else:
            print("Not Found")
