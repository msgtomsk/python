import solution,adminlogin
class cmain:
    def fun_main(self):
        while True:
            choice1 = 0
            print("\n*** Welcome to payroll management system ***\n")            
            print("1.Admin\n2.Employee\n3.Exit")
            try:
                choice1 = int(input("Enter : "))
                if choice1 == 1:
                    adminlogin.fun_admin()
                elif choice1 == 2:
                    solution.fun_sol()
                elif choice1 == 3:
                    break
                else:
                    print("Invalid choice\n")                             
            except Exception:
                print("Invalid input")
                break
obj = cmain()
obj.fun_main()
