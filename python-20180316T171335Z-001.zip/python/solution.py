import signup
import signin
def fun_sol():
    print("\n*** WELCOME ***")
    print("\n1.Signup\n2.Signin")
    choice = int(input("Enter : "))
    if choice == 1:
        signup.newuser()
    elif choice == 2:
        if signin.Login():
            print("***")
    else:
        print("\nInvalid choice\n")
        print()

