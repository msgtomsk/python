import factory,adminlogin,random
def fun_pay():
    if adminlogin.fun_admin().status == "true":
        
        print("salary : ",random.randint(30000,35000))
    else:
        print("Try Later\n")
def fun_rep():
